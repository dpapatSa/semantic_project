module.exports = {
  presets: [
    '@vue/cli-plugin-babel/preset'
  ]
}


// Nikolaos Astyrakakis MTP235