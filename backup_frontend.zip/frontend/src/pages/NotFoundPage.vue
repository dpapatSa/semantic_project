<template>
  <div class=" full-screen"> 
    <div class="wrapper wrapper-full-page section content">
      <div class="">
        <div class="container">
          <div class="row">
            <div class="col-md-8 col-md-offset-2 text-center">
              <br>
              <br>
              <br>
              <br>
              <br>
              <br>
              <br>

              <h2 class="title text-danger">404 Not Found</h2>
              <h2 class="title">Oops! It seems that this page does not exist.</h2>
            </div>
          </div>
        </div>
      </div>
    </div> 
  </div>
</template>

<script>
export default {};
</script>
