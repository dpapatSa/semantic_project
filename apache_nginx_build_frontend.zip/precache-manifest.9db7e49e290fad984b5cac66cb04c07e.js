self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "96d9066ba6bba10a9cba",
    "url": "/css/app.ab04a53a.css"
  },
  {
    "revision": "996d8248f580f8e26e6c45c67da9b5a6",
    "url": "/favicon.png"
  },
  {
    "revision": "03ef1918e505c3e3471f9369ef7a638f",
    "url": "/fonts/nucleo.03ef1918.eot"
  },
  {
    "revision": "5987dd12fea78ce5f97ae601b08ec03c",
    "url": "/fonts/nucleo.5987dd12.woff2"
  },
  {
    "revision": "b17a118e13e53558658b681a0ebdad82",
    "url": "/fonts/nucleo.b17a118e.ttf"
  },
  {
    "revision": "f0b489a5dbbff08833d21024f9fcbd4e",
    "url": "/fonts/nucleo.f0b489a5.woff"
  },
  {
    "revision": "d25412bcd9af1fb98017c8144a4e40d1",
    "url": "/img/default-avatar.png"
  },
  {
    "revision": "bfca8a87dd742a3dbc6101a712829e94",
    "url": "/index.html"
  },
  {
    "revision": "96d9066ba6bba10a9cba",
    "url": "/js/app.d0503d5f.js"
  },
  {
    "revision": "4550ebe27d05b35c5a27",
    "url": "/js/chunk-vendors.15d42dfc.js"
  },
  {
    "revision": "72914a2958f4ddec1a6a",
    "url": "/js/common.15816884.js"
  },
  {
    "revision": "c04b61504c0741559749",
    "url": "/js/common~dashboard.4455198d.js"
  },
  {
    "revision": "f239e37b265dcd65d828",
    "url": "/js/dashboard.fa7eaaba.js"
  },
  {
    "revision": "1a167cfd82a1a7480ea601fccc8d7e18",
    "url": "/manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  }
]);